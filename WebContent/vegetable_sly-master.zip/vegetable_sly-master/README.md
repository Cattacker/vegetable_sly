请新建localization包，并创建LocalSettings.java

LocalSettings需包含以下静态变量
*databaseURL
*username
*password